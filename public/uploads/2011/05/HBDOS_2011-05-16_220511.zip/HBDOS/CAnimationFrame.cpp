#include "CAnimationFrame.h"

CAnimationFrame::CAnimationFrame() {
	this->Reset(); 
}
void CAnimationFrame::Reset( ) {
	this->m_frameCount = 0 ; 
	for( uint16 offset = 0 ; offset < NUMBER_OF_FRAMES ; offset++) {
		this->m_frameDelay[offset] = 0 ; 
	}
	memset( m_ledData, 0, NUMBER_OF_BYTES_PER_FRAME ); 
}
uint8 CAnimationFrame::GetFrame( uint8 frame ) {
	if( this->m_frameCount == 0 ) {
		return 0; 
	}
	if( frame > this->m_frameCount ) {
		frame = this->m_frameCount % frame ; 
	}
	return frame ; 
}

uint16 CAnimationFrame::GetFrameDelay( const uint8 frame /* = 0 */) {
	uint8 frame_offset = this->GetFrame( frame ) ; 
	return this->m_frameDelay[ frame_offset ] ;
}

uint8 CAnimationFrame::GetLEDRed( const uint8 led, const uint8 column /*= 0*/, const uint8 frame /*= 0*/ ) { 
	uint8 frame_offset = this->GetFrame( frame ) ; 
	return this->m_ledData[frame_offset][ column * NUMBER_OF_LEDS + (led * NUMBER_OF_COLORS + 0)]; 
}
uint8 CAnimationFrame::GetLEDGreen( const uint8 led, const uint8 column /*= 0*/, const uint8 frame /*= 0*/ ) { 
	uint8 frame_offset = this->GetFrame( frame ) ; 
	return this->m_ledData[frame_offset][ column * NUMBER_OF_LEDS + (led * NUMBER_OF_COLORS +1)]; 
}
uint8 CAnimationFrame::GetLEDBlue( const uint8 led, const uint8 column /*= 0*/, const uint8 frame /*= 0*/ ) { 
	uint8 frame_offset = this->GetFrame( frame ) ; 
	return this->m_ledData[frame_offset][ column * NUMBER_OF_LEDS + (led * NUMBER_OF_COLORS +2)]; 
}
/*
bool CAnimationFrame::Load( char * filename ) {
	if( filename == NULL ) {
		return false; 
	}

	// Open the file for binary read. 
	FILE * stream = fopen( filename , "rb" ); 
	if( stream == NULL ) {
		return false ; 
	}

	this->m_frameCount = 0 ; 
	while( this->m_frameCount < NUMBER_OF_FRAMES ) {
		// First two BYTES are the frame delay
		if( fread( &this->m_frameDelay[ this->m_frameCount ], sizeof( uint16 ), 1, stream ) != 1 ) {
			break ; 
		}

		// The next 192 BYTES are the color data m_ledData[ NUMBER_OF_BYTES_PER_FRAME ]
		if( fread( &this->m_ledData[ this->m_frameCount ], NUMBER_OF_BYTES_PER_FRAME, 1, stream ) != 1 ) {
			break; 
		}
		this->m_frameCount++; 
	}
	fclose( stream ) ; 

	if( this->m_frameCount <= 0 ) {
		return false; // No frames where loaded 
	}
	// At lest one frame was loaded correcty. 
	return true ; 
}
*/
