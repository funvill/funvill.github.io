#include "CPresetTestPattern.h"

uint8 CPresetTestPattern::GetBrightnesss( const uint8 color, const uint8 led, const uint8 column, const uint8 frame /*= 0*/ ) {
	if( led    % (NUMBER_OF_COLORS +1) == color || 
		column % (NUMBER_OF_COLORS +1) == color ) {
		return 0xFF; 
	}	
	return 0x00;
}

uint8 CPresetTestPattern::GetLEDRed( const uint8 led, const uint8 column /*= 0*/, const uint8 frame /*= 0*/ ) {
	return this->GetBrightnesss( 0, led, column, frame ); 
}
uint8 CPresetTestPattern::GetLEDGreen( const uint8 led, const uint8 column /*= 0*/, const uint8 frame /*= 0*/ ) {
	return this->GetBrightnesss( 1, led, column, frame ); 
}
uint8 CPresetTestPattern::GetLEDBlue( const uint8 led, const uint8 column /*= 0*/, const uint8 frame /*= 0*/ ) {
	return this->GetBrightnesss( 2, led, column, frame ); 
}
