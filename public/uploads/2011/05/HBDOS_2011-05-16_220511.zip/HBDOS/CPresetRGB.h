/*
 * CPresetRGB.h
 *
 *  Created on: May 12, 2011
 *      Author: Steve
 */

#ifndef CPRESETRGB_H_
#define CPRESETRGB_H_

#include "CFrameBase.h"

class CPresetRGB : public CFrameBase {
private:
	uint8 m_red;
	uint8 m_green;
	uint8 m_blue;

public:
	CPresetRGB();

	void Set( const uint8 red, const uint8 green, const uint8 blue ) {
		this->m_red = red;
		this->m_green = green;
		this->m_blue = blue;
	}

	uint8 GetLEDRed		( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) { return this->m_red ;}
	uint8 GetLEDGreen	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) { return this->m_green ; }
	uint8 GetLEDBlue	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) { return this->m_blue ; }
	uint8 GetFrameCount( ) { return 1 ; }
};

#endif /* CPRESETRGB_H_ */
