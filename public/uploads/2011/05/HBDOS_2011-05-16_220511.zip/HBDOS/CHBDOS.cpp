#include "CHBDOS.h"

/* Ports and Pins
 Direct port access is much faster than digitalWrite.
 You must match the correct port and pin as shown in the table below.
 Arduino Pin        Port        Pin
 13 (SCK)           PORTB       5
 12 (MISO)          PORTB       4
 11 (MOSI)          PORTB       3
 10 (SS)            PORTB       2
 9                 PORTB       1
 8                 PORTB       0
 7                 PORTD       7
 6                 PORTD       6
 5                 PORTD       5
 4                 PORTD       4
 3                 PORTD       3
 2                 PORTD       2
 1 (TX)            PORTD       1
 0 (RX)            PORTD       0
 A5 (Analog)        PORTC       5
 A4 (Analog)        PORTC       4
 A3 (Analog)        PORTC       3
 A2 (Analog)        PORTC       2
 A1 (Analog)        PORTC       1
 A0 (Analog)        PORTC       0
 */

// Defines for use with Arduino functions
#define clockpin   13 // CI
#define enablepin  10 // EI
#define latchpin    9 // LI
#define datapin    11 // DI

// Defines for direct port access
#define CLKPORT PORTB
#define ENAPORT PORTB
#define LATPORT PORTB
#define DATPORT PORTB
#define CLKPIN  5
#define ENAPIN  2
#define LATPIN  1
#define DATPIN  3


CHBDOS::CHBDOS() {
	this->m_frames			= NULL;
	this->m_animationFrames = NULL;
	this->Reset();

	this->Connect();

	// Set up the arduino specific code
	pinMode(datapin, OUTPUT);
	pinMode(latchpin, OUTPUT);
	pinMode(enablepin, OUTPUT);
	pinMode(clockpin, OUTPUT);
	digitalWrite(latchpin, LOW);
	digitalWrite(enablepin, LOW);

	this->Log("Starting up...\n");

	// Load a preset anyways so there is always something being shown.
	this->LoadPreset("Startup");
	this->m_current_state	= CHBDOS::state_idle ;
}

void CHBDOS::Reset() {

	this->m_current_frame	= 0 ;
	this->m_current_column 	= 0 ;
	this->m_current_frame_timeout = 1 ;

	// Frames
	if( this->m_frames != NULL ) {
		delete this->m_frames;
		this->m_frames = NULL;
	}
	if( this->m_animationFrames != NULL ) {
		delete this->m_animationFrames;
		this->m_animationFrames = NULL;
	}
}

void CHBDOS::Run() {
	this->StateMachine();
	if( this->m_current_state == CHBDOS::state_idle ) {
		this->StreamLEDData();
	}
}

void CHBDOS::Log(const char * message) {
	this->m_serial.SendData( message, strlen( message ) ) ;
}
void CHBDOS::LogI(const uint32 i) {
	char buff[20];
	sprintf(buff, "%u", i ) ;
	this->Log( buff );
}


bool CHBDOS::LoadPreset( const char * name )
{
	// Remove any current presets. 
	this->Reset(); 
	
	this->Log("Loading preset: ");
	this->Log( name );
	this->Log( "\n" );

	// Switch of different preset. 
	if( strcmp( name, "Random" ) == 0 ) {
		this->m_frames = new CPresetRandom(); 
	} else if( strcmp( name, "TestPattern" ) == 0  ) {
		this->m_frames = new CPresetTestPattern(); 
	} else if( strcmp( name, "RGB" ) == 0 ) {
		this->m_frames = new CPresetRGB();
	} else if( strcmp( name, "Animation" ) == 0 ) {
		this->m_animationFrames = new CAnimationFrame() ; 
		this->m_frames = this->m_animationFrames ; 
	} else if( strcmp( name, "Startup" ) == 0 ) {
		CPresetRGB * new_frame = new CPresetRGB();
		if( new_frame != NULL ) {
			this->m_frames = new_frame ;
			new_frame->Set( 0, 0x33, 0 );
		}
	}

	if( this->m_frames == NULL ) {
		this->Log("FAILED to load perset\n");
		return false; 
	}
	this->Log("OK\n");
	return true ; 
}

bool CHBDOS::Connect( ) {
	if( ! this->m_serial.Open( DEFAULT_SERIAL_PORT, DEFAULT_SERIAL_BAUD ) ) {
		return false; 
	}
	return true; 
}

// <command><lenght><data>
// Commnd = 2 BYTES, 
//          "DL" = Download 
// Length = 4 BYTES, Length of the data section 

bool CHBDOS::Download() 
{
	/*
	if( this->m_animationFrames == NULL ) {
		// Nothing to send
		return false;
	}

	// data size:
	uint32 data_size = this->m_animationFrames->GetFrameCount() * (NUMBER_OF_BYTES_PER_FRAME+2) ; 
	if( data_size <= 0 ) {
		return false; // Nothing to send. 
	}

	// Send the download command 
	if( ! this->m_serial.SendData( (void *) "DL", 2 ) ) {
		// Failed 
		return false; 
	}

	// Send the data length size 
	if( ! this->m_serial.SendData( &data_size, sizeof( uint32 ) ) ) {
		// Failed 
		return false; 
	}

	// Send the data. 
	for( uint8 frameOffset = 0 ; frameOffset < this->m_animationFrames->GetFrameCount() ; frameOffset++ ) 
	{		
		// Send the delay. 
		if( ! this->m_serial.SendData( &this->m_animationFrames->m_frameDelay[frameOffset], sizeof( uint16 ) ) ) {
			return false; // Could not send the entire message. 
		}

		// Send the color value 
		if( ! this->m_serial.SendData( this->m_animationFrames->m_ledData[frameOffset], NUMBER_OF_BYTES_PER_FRAME ) ) {
			return false; // Could not send the entire message. 
		}
	}
*/
	// Everything looks good. 
	return true; 
}


// <data lenght><data>
// Length = 4 BYTES, Length of the data section 
bool CHBDOS::Upload() {

	this->Reset();
	this->m_animationFrames = new CAnimationFrame() ;
	this->m_frames = this->m_animationFrames ;
	if( this->m_frames == NULL ) {
		this->Log("FAILED to load CAnimationFrame\n");
		return false;
	}

	this->Log("Uploading\n");
	this->Log("Bytes waiting=");
	this->LogI( this->m_serial.ReadDataWaiting() );
	this->Log("\n");

	uint32	stream_offset	= 0;
	char	c ;

	this->Log("FYI: Starting time=");
	this->LogI( CTime::Get() );
	this->Log("\n");

	unsigned long timeout = CTime::Get() + UPLOAD_TIMEOUT ;
	while( true ) {

		int bytes_waitting = this->m_serial.ReadDataWaiting() ;
		if( bytes_waitting > 0  ) {
			if( this->m_serial.ReadData( &c, 1 ) == 1 ) {
				// We received a BYTE
				// Reset the interbyte timer.
				timeout = CTime::Get() + UPLOAD_TIMEOUT ; // Reset the timer.

				// If this is the first byte then it is the frame count.
				if( stream_offset == 0 ) {
					this->m_animationFrames->m_frameCount = c ;
					if( this->m_animationFrames->m_frameCount > NUMBER_OF_FRAMES ) {
						this->Log("Error: frame count is too large. count=");
						this->LogI( this->m_animationFrames->m_frameCount );
						this->Log("\n");
					}

				} else {
					uint8 frame_offset = (int) (stream_offset-1) / (NUMBER_OF_BYTES_PER_FRAME +2);
					uint8 byte_offset  = (int) (stream_offset-1) - (frame_offset * (NUMBER_OF_BYTES_PER_FRAME+2) );
					if( frame_offset > this->m_animationFrames->m_frameCount ){
						this->Log("Error: More bytes then expected\n");
						return false;
					}

					if( frame_offset > NUMBER_OF_FRAMES ) {
						this->Log("Error out of bounds frame_offset=");
						this->LogI( frame_offset );
						this->Log("\n");
						return false ;
					}

					if( byte_offset > NUMBER_OF_BYTES_PER_FRAME+2 ) {
						this->Log("Error out of bounds byte_offset=");
						this->LogI( byte_offset );
						this->Log("\n");

						return false ;
					}

					// Frame delay
					if( byte_offset == 0 ) {
						uint8 * p = ( uint8 * ) &this->m_animationFrames->m_frameDelay[frame_offset] ;
						p++;
						*p=c;
					} else if( byte_offset == 1 ) {
						uint8 * p = ( uint8 * ) &this->m_animationFrames->m_frameDelay[frame_offset] ;
						*p=c;

					} else {
						// Color info
						this->m_animationFrames->m_ledData[ frame_offset ][ byte_offset-2 ] = c ;
					}

				}


				this->Log(".");
				stream_offset++;
			}
		}
		// Check to see if we are done
		if( stream_offset > 0 && stream_offset > this->m_animationFrames->m_frameCount * (NUMBER_OF_BYTES_PER_FRAME+2) ) {
			this->Log("Done\n");
			break;
		}

		// Check to see if we have timed out
		if( timeout < CTime::Get() ) {
			this->Log("Error: Timeout=");
			this->LogI( timeout );
			this->Log(" ");
			this->Log(" Recv=");
			this->LogI( stream_offset );
			this->Log("\n");
			return false;
		}
	}

	this->Log(" Recv=");
	this->LogI( stream_offset );
	this->Log(" frameCount=");
	this->LogI( this->m_animationFrames->m_frameCount );
	this->Log("\n");
	return true;
}

void CHBDOS::DoChangeColor() {
	uint8 colorRed ;
	if( this->m_serial.ReadData(&colorRed,1) != 1 ) {
		return ; // Nothing received
	}
	uint8 colorGreen ;
	if( this->m_serial.ReadData(&colorGreen,1) != 1 ) {
		return ; // Nothing received
	}
	uint8 colorBlue ;
	if( this->m_serial.ReadData(&colorBlue,1) != 1 ) {
		return ; // Nothing received
	}

	this->Reset();
	CPresetRGB * new_frame = new CPresetRGB();
	if( new_frame != NULL ) {
		this->m_frames = new_frame ;
		new_frame->Set( colorRed, colorGreen, colorBlue );
	}

	this->Log("Changed color ");
	this->LogI( colorRed );
	this->Log(",");
	this->LogI( colorGreen );
	this->Log(",");
	this->LogI( colorBlue );
	this->Log("\n");
}

void CHBDOS::StateMachine() {
	if( this->m_serial.ReadDataWaiting() == 0 ) {
		return ; // Nothing to do
	}

	uint8 c ;
	if( this->m_serial.ReadData(&c,1) != 1 ) {
		return ; // Nothing received
	}

	// We have received a BYTE.
	switch( this->m_current_state ) {
		default:
		case CHBDOS::state_idle: {
			// Check for peramble
			if( c == 0xFF ) {
				this->m_current_state = CHBDOS::state_preabmle;
			}
			break;
		}

		case CHBDOS::state_preabmle: {
			if( c == 0x55 ) {
				this->m_current_state = CHBDOS::state_function_code;
			} else {
				this->m_current_state = CHBDOS::state_idle ;
			}
			break;
		}

		case CHBDOS::state_function_code: {
			switch( c ) {
				case CHBDOS::function_change_color:
					this->DoChangeColor();
					break;
				case CHBDOS::function_upload:
					this->Upload();
					this->DebugDumpFrame();
					break;

				default:
					// unknown function code
					this->Log("Error: unknown function code\n");
					break;
			} // End of function code switch statement
			this->m_current_state = CHBDOS::state_idle ;
			break;
		}
	}// End of switch statement

}

void CHBDOS::DebugDumpFrame() {
	if( this->m_frames == NULL ) {
		return ; // Error. Nothing to stream out.
	}

	this->Log("Frame count=");
	this->LogI( this->m_frames->GetFrameCount() );
	this->Log("\n");

	for( int frame_offset = 0 ; frame_offset < this->m_frames->GetFrameCount() ; frame_offset++ ) {

		this->Log("Frame {");
		this->LogI(frame_offset);
		this->Log("}\n\n");

		for( int column_offset = 0 ; column_offset < NUMBER_OF_COLUMNS ; column_offset++ ) {
			for( int led_offset = 0 ; led_offset < NUMBER_OF_LEDS ; led_offset++ ) {

				this->Log("Col=");
				this->LogI(column_offset);
				this->Log(", LED=");
				this->LogI(led_offset);
				this->Log(" [");

				for( int color_offset = 0 ; color_offset < NUMBER_OF_COLORS ; color_offset++ ) {
					unsigned char brightness = 0x00;
					if( color_offset == 1 ) {
						brightness = this->m_frames->GetLEDRed   (led_offset, column_offset, frame_offset );
					} else if( color_offset == 2 ) {
						brightness = this->m_frames->GetLEDGreen (led_offset, column_offset, frame_offset );
					} else if( color_offset == 0 ) {
						brightness = this->m_frames->GetLEDBlue  (led_offset, column_offset, frame_offset );
					}

					this->LogI( brightness );
					this->Log(",");
				}
				this->Log("]\n");
			}
		}
	}
}


void CHBDOS::StreamLEDData()
{
	/*
	if( CTime::GetMs() < this->m_current_frame_timeout  ) {
		delay( 100 ) ;
		return ;
	}
	*/
	if( this->m_frames == NULL ) {
		return ; // Error. Nothing to stream out.
	}

	for( int led_offset = 0 ; led_offset < NUMBER_OF_LEDS ; led_offset++ ) {
		for( int color_offset = 0 ; color_offset < NUMBER_OF_COLORS ; color_offset++ ) {
			unsigned char brightness = 0x00;
			if( color_offset == 1 ) {
				// brightness = 0xFF;
				brightness = this->m_frames->GetLEDRed   (led_offset, this->m_current_column, this->m_current_frame);
			} else if( color_offset == 2 ) {
				brightness = this->m_frames->GetLEDGreen (led_offset, this->m_current_column, this->m_current_frame);
			} else if( color_offset == 0 ) {
				brightness = this->m_frames->GetLEDBlue  (led_offset, this->m_current_column, this->m_current_frame);
			}

			for( int bit = 0 ; bit < 12 ; bit++ ) {
				if( bit < 8 ) {
					if( (brightness >> (8-bit) ) & 1 ) {
						DATPORT |= (1 << DATPIN);
					} else {
						DATPORT &= ~(1 << DATPIN);
					}
				} else {
					DATPORT &= ~(1 << DATPIN);
				}

				CLKPORT |= (1 << CLKPIN);
				CLKPORT &= ~(1 << CLKPIN);
			}
		}
	}
	LATPORT |= (1 << LATPIN);
	LATPORT &= ~(1 << LATPIN);


	// Increment the column for next time.
	/*
	this->m_current_column++;
	if( this->m_current_column > NUMBER_OF_COLUMNS ) {
		this->m_current_column = 0 ;

*/
		uint16 frame_delay = this->m_frames->GetFrameDelay( this->m_current_frame );
		delay( frame_delay );

		/*
		if( frame_delay > 0) {
			this->m_current_frame_timeout = CTime::GetMs() + frame_delay ;
		} else {
			this->m_current_frame_timeout = 1 ;
		}

		delay( 100 );
		*/

		// Increment the frame.
		this->m_current_frame++;
		if( this->m_current_frame >= this->m_frames->GetFrameCount() ) {
			this->m_current_frame = 0 ;
		}
	// }

}


