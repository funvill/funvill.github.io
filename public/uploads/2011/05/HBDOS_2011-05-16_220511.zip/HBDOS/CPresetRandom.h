#pragma once
#include "CFrameBase.h"

#include <stdio.h>
#include <stdlib.h>

class CPresetRandom : public CFrameBase
{
private:
	uint8 GetRandom(); 

public:
	uint8 GetLEDRed   ( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
	uint8 GetLEDGreen ( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
	uint8 GetLEDBlue  ( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
};
