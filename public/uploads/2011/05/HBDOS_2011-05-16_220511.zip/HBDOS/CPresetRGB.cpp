/*
 * CPresetRGB.cpp
 *
 *  Created on: May 12, 2011
 *      Author: Steve
 */

#include "CPresetRGB.h"

CPresetRGB::CPresetRGB() {
	this->m_red = 0x00 ;
	this->m_green = 0x00 ;
	this->m_blue = 0x00 ;
}


