/*
 * CTime.cpp
 *
 *  Created on: May 12, 2011
 *      Author: Steve
 */

#include "CTime.h"

CTime::CTime() {
	// TODO Auto-generated constructor stub

}

CTime::~CTime() {
	// TODO Auto-generated destructor stub
}
