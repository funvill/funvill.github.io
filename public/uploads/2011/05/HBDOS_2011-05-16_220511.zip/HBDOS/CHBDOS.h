#ifndef __CHBDOS_H__
#define __CHBDOS_H__

// Common 
#include "data_types.h"

// Serial 
#include "Serial.h"

// Presets 
#include "CAnimationFrame.h"
#include "CPresetRandom.h" 
#include "CPresetTestPattern.h"
#include "CPresetRGB.h"

// Time
#include "CTime.h"

#define DEFAULT_SERIAL_PORT			2
#define DEFAULT_SERIAL_BAUD			9600

#define UPLOAD_TIMEOUT				3

class CHBDOS {

	private: // Should be private after testing.
		CSerial 			m_serial;
		CFrameBase			* m_frames; 
		CAnimationFrame		* m_animationFrames;

		uint16				m_current_frame;
		uint16				m_current_column;
		uint8				m_current_state;
		unsigned long 		m_current_frame_timeout;


		enum {
			state_idle			= 1,
			state_preabmle		= 2,
			state_function_code	= 3,
			state_busy			= 4,

		};

		enum {
			function_change_color	= 1,
			function_download		= 3,
			function_upload			= 2,
		};

		void StateMachine();

		// Actions
		void DoChangeColor();

		// Resets the system. 
		void Reset(); 

		// Loads a perset animation
		bool LoadPreset( const char * name ) ;

		void StreamLEDData();

		CFrameBase * GetFrameData () { return this->m_frames; } 

		// Communications
		bool Connect( ) ;
		bool Download();
		bool Upload() ;

		void Log(const char * message);
		// void Log(const char c);
		void LogI(const uint32 i);

		void DebugDumpFrame();

	public:
		CHBDOS();
		void Run();
};


#endif // __CHBDOS_H__
