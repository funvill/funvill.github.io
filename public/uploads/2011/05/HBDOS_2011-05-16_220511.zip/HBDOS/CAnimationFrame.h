#ifndef __CAnimationFrame_h__
#define __CAnimationFrame_h__

#include "data_types.h"
#include "CFrameBase.h"

// File IO 
#include <stdio.h>

// MemSet 
#include <stdio.h>
#include <string.h>

class CAnimationFrame : public CFrameBase 
{
private:
	uint8	GetFrame( uint8 frame ) ; 	

public:
	CAnimationFrame(); 
	void Reset(); 

	uint16	m_frameDelay[NUMBER_OF_FRAMES] ; 
	uint8	m_ledData	[NUMBER_OF_FRAMES][NUMBER_OF_BYTES_PER_FRAME ] ; 
	uint8	m_frameCount; 


	uint8   GetFrameCount( ) { return this->m_frameCount ; }; 
	uint16  GetFrameDelay( const uint8 frame = 0 ); 
	uint8	GetLEDRed	 ( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
	uint8	GetLEDGreen	 ( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
	uint8	GetLEDBlue	 ( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 

	// Loads the current animation frames from the file system 
	// bool	Load( char * filename );

};


#endif // __CAnimationFrame_h__
