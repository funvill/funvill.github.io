/*
 * main.cpp
 *
 *  Created on: Mar 5, 2010
 *      Author: ssmethurst
 */
#include <WProgram.h>
#include "CHBDOS.h"


__extension__ typedef int __guard __attribute__((mode (__DI__)));
int __cxa_guard_acquire(__guard *g) {return !*(char *)(g);}
void __cxa_guard_release (__guard *g) {*(char *)g = 1;}
void __cxa_guard_abort (__guard *) {}
extern "C" void __cxa_pure_virtual() { cli(); for (;;); }
void * operator new(size_t size) { return malloc(size); }
void operator delete(void * ptr) { free(ptr); }
void * operator new[](size_t size) { return malloc(size); }
void operator delete[](void * ptr) { if (ptr) { free(ptr); } }


CHBDOS * hbdos;
// The setup() method runs once, when the sketch starts
void setup()   {
	hbdos = new CHBDOS();
}

// the loop() method runs over and over again,
// as long as the Arduino has power

void loop() {
	if( hbdos != NULL ) {
		hbdos->Run();
	}
}

int main(void) {

  /* Must call init for arduino to work properly */
  init();
  setup();

  for (;;) {
	  loop();
  } // end for
} // end main
