#include "CFrameBase.h"
/*
bool CFrameBase::Save( char * filename ) {
	if( filename == NULL ) {
		return false; 
	}

	// Open the file for binary read. 
	FILE * stream = fopen( filename , "wb" ); 
	if( stream == NULL ) {
		return false ; 
	}

	for( uint8 frame_offset = 0; frame_offset < this->GetFrameCount(); frame_offset++ ) {
		// First two BYTES are the frame delay
		uint16 frameDelay = this->GetFrameDelay( frame_offset ); 
		if( fwrite( &frameDelay, sizeof( uint16 ), 1, stream ) != 1 ) {
			fclose( stream ) ; 
			return false; // Could not write the frame delay to the file system. 
		}

		for( int column_offset = 0 ; column_offset < NUMBER_OF_COLUMNS ; column_offset++ ) {
			for( int led_offset = 0 ; led_offset < NUMBER_OF_LEDS ; led_offset++ ) {
				uint8 colorRed		= this->GetLEDRed  ( led_offset, column_offset, frame_offset ); 
				uint8 colorGreen    = this->GetLEDGreen( led_offset, column_offset, frame_offset ); 
				uint8 colorBlue     = this->GetLEDBlue ( led_offset, column_offset, frame_offset ); 
				if( fwrite( &colorRed, 1, 1, stream ) != 1 ) {
					fclose( stream ) ; 
					return false; // Could not write the frame delay to the file system. 
				}
				if( fwrite( &colorGreen, 1, 1, stream ) != 1 ) {
					fclose( stream ) ; 
					return false; // Could not write the frame delay to the file system. 
				}				
				if( fwrite( &colorBlue, 1, 1, stream ) != 1 ) {
					fclose( stream ) ; 
					return false; // Could not write the frame delay to the file system. 
				}
			}
		}
	}
	fclose( stream ) ; 
	return true ; 
}
*/

