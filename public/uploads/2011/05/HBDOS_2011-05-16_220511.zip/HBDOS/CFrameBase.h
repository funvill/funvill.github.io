#pragma once

#include "data_types.h"

// File IO 
#include <stdio.h>

// Settings, Changeable
#define NUMBER_OF_LEDS				64
#define	NUMBER_OF_COLUMNS			1
#define	NUMBER_OF_FRAMES			3

// Not editable.
#define NUMBER_OF_COLORS			3
#define	NUMBER_OF_BYTES_PER_FRAME	(NUMBER_OF_COLORS * NUMBER_OF_LEDS * NUMBER_OF_COLUMNS)


class CFrameBase
{
public:

	virtual uint8  GetLEDRed	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) = 0 ; 
	virtual uint8  GetLEDGreen	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) = 0 ; 
	virtual uint8  GetLEDBlue	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) = 0 ; 

	// A frame delay of zero (0) defines a single frame. 
	virtual uint16 GetFrameDelay( const uint8 frame = 0 ) { return 0; }
	virtual uint8  GetFrameCount( ) { return 1 ; } 

	// Saves the current animation frames to the file system 
	// bool	Save( char * filename );

};
