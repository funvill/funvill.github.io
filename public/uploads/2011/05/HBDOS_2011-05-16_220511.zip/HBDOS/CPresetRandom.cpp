#include "CPresetRandom.h"

uint8 CPresetRandom::GetRandom() { return rand() % 255 + 1 ; } 
uint8 CPresetRandom::GetLEDRed   ( const uint8 led, const uint8 column, const uint8 frame ) { return this->GetRandom(); } 
uint8 CPresetRandom::GetLEDGreen ( const uint8 led, const uint8 column, const uint8 frame ) { return this->GetRandom(); }  
uint8 CPresetRandom::GetLEDBlue  ( const uint8 led, const uint8 column, const uint8 frame ) { return this->GetRandom(); } 

