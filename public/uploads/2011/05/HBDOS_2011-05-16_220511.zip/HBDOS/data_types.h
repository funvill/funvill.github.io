#ifndef __data_types_h__
#define __data_types_h__

typedef unsigned char	uint8; 
typedef char			sint8; 
typedef unsigned short	uint16;
typedef short			sint16;
typedef unsigned int	uint32;
typedef int				sint32;
#ifndef NULL 
#define NULL 0
#endif // NULL 



#endif // __data_types_h__
