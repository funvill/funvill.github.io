// Serial.h

#ifndef __SERIAL_H__
#define __SERIAL_H__
#pragma once

class CSerial
{
private:
	bool m_isOpened;
public:
	CSerial();
	~CSerial();

	bool Open( int nPort = 2, int nBaud = 9600 );
	void Close( );

	int ReadData( const void * buffer, int max_length);
	int SendData( const void * buffer, int length );
	bool IsOpened();
	int ReadDataWaiting();
};

#endif
