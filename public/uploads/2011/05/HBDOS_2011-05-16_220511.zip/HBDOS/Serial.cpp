#include "Serial.h"
#include "HardwareSerial.h"

CSerial::CSerial() {
	this->m_isOpened = false ;
}
CSerial::~CSerial(){
	this->Close();
}
bool CSerial::Open( int nPort /*= 2*/, int nBaud /* = 9600 */ ){
	 // start the serial library:
	 Serial.begin(nBaud);

	 // There does not seem to be a way to tell if the port was open correctly.
	 // Always return true.
	 this->m_isOpened = true ;
	 return true;
}
void CSerial::Close( ){
	this->m_isOpened = false ;
	Serial.end();
}
bool CSerial::IsOpened() {
	return this->m_isOpened ;
}

int CSerial::ReadDataWaiting() {
	return Serial.available();
}

int CSerial::ReadData( const void * buffer, int max_length){
	if( ! this->IsOpened() ) {
		return 0; // Com port not opened.
	}

	int read_bytes = 0 ;
	char * p = (char *) buffer ;
	while( this->ReadDataWaiting() && read_bytes < max_length )
	{
		*p = Serial.read();
		p++;
		read_bytes++;
	}
	return read_bytes;
}
int CSerial::SendData( const void * buffer, int length ) {
	if( ! this->IsOpened() ) {
		return 0; // Com port not opened.
	}
	Serial.write((uint8_t *) buffer, length);
	return length;
}
