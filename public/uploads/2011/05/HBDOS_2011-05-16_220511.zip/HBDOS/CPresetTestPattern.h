#pragma once
#include "CFrameBase.h"

class CPresetTestPattern : public CFrameBase
{
private:
	uint8 GetBrightnesss( const uint8 color, const uint8 led, const uint8 column, const uint8 frame = 0 ) ;

public:

	uint8 GetLEDRed		( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
	uint8 GetLEDGreen	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
	uint8 GetLEDBlue	( const uint8 led, const uint8 column = 0, const uint8 frame = 0 ) ; 
};
