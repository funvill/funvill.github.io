/*
 * CTime.h
 *
 *  Created on: May 12, 2011
 *      Author: Steve
 */

#ifndef CTIME_H_
#define CTIME_H_

#include "wiring.h"

class CTime {
public:
	CTime();
	virtual ~CTime();

	static unsigned long Get() { return CTime::GetMs() / 1000; }
	static unsigned long GetMs() { return millis(); }
};

#endif /* CTIME_H_ */
