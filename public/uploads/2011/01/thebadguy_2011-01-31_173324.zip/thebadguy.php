<?php 

function GetPage( $target_url ) {

	$userAgent = 'Googlebot/2.1 (http://www.googlebot.com/bot.html)';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
	curl_setopt($ch, CURLOPT_URL,$target_url);
	curl_setopt($ch, CURLOPT_FAILONERROR, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	$html = curl_exec($ch);
	if (!$html) {
		echo "url=[".$target_url."] cURL error (". curl_errno($ch) ."):" . curl_error($ch) ."<br />\n";
		return false; 
	}	
	return $html ; 
}

function SaveFile( $path, $content ) {
	$fh = fopen($path, 'w') or die("can't open file");
	if( $fh != FALSE ) {
		fwrite($fh, $content);
		fclose($fh);
		return true ; 
	}
	return false; 
}


function GetFrom_mp3lyrics(  $band, $title ) {

	$search = array( " " ); 
	$url = "http://edit.mp3lyrics.org/". substr( $band, 0, 1) ."/". str_replace( $search, "-", $band ) ."/". str_replace( $search, "-", $title ) ."/" ; 
	
	$html = GetPage( strtolower ($url ) ) ; 
	if( $html == FALSE ) {
		echo "Error: [$band], [$title] - Could not get page<br />";
		return false; 
	}

	$doc = new DOMDocument();
	@$doc->loadHTML($html);
	$xpath = new DOMXpath($doc);
	$elements = $xpath->query("//textarea[@id]");

	$song_text = ''; 
	if (!is_null($elements)) {
	  foreach ($elements as $element) {
		$nodes = $element->childNodes;
		foreach ($nodes as $node) {
			$song_text .= $node->nodeValue. "\n";
		}
		break;
	  }
	}
	return $song_text ; 
}


function GetFrom_seeklyrics(  $band, $title ) {

	$search = array( " " ); 
	$url = "http://www.seeklyrics.com/lyrics/". str_replace( $search, "-", $band ) ."/". str_replace( $search, "-", $title ) .".html" ; 
	
	$html = GetPage( $url ) ; 
	if( $html == FALSE ) {
		echo "Error: [$band], [$title] - Could not get page<br />";
		return false; 
	}

	$doc = new DOMDocument();
	@$doc->loadHTML($html);
	$xpath = new DOMXpath($doc);
	$elements = $xpath->query("//div[@id='songlyrics']");

	$song_text = ''; 
	if (!is_null($elements)) {
	  foreach ($elements as $element) {
		$nodes = $element->childNodes;
		foreach ($nodes as $node) {
			$song_text .= $node->nodeValue. "\n";
		}
		break;
	  }
	}
	return $song_text ; 
}

function Scraper( $band, $title ) {

	$song_text = GetFrom_seeklyrics ( $band, $title ) ;
	if( $song_text == FALSE  ) {
		GetFrom_mp3lyrics( $band, $title ) ; 
	}
	
	
	
	if( strlen( $song_text ) <= 0 ) {
		echo "Error: [$band], [$title] - Could not extract song text <br />";
		return false; 
	}
	
	$search = array( " ", ",", "&", "#" ); 
	$filename = str_replace ( $search, '_', $band ) . '__' . str_replace ( $search, '_', $title ) . ".txt"; 	
	if( ! SaveFile($filename, $song_text ) ) {
		echo "Error: [$band], [$title] - Could not save <br />";
		// flush();
		return false; 
	} else {
		echo "GOOD: [$band], [$title] == OK!!! <br />";
		// flush();
		return true; 		
	}
}


// Done 
Scraper( "Sloan", 				"All Used Up" );
Scraper( "Sia", 				"Breathe Me");
Scraper( "Muse",				"Starlight" ); 
Scraper( "Everclear",			"Santa Monica (Watch The World Die)");
Scraper( "Coldplay",			"Yellow");
Scraper( "Beck",				"Girl");
Scraper( "Jimmy Eat World",		"The Middle");
Scraper( "Fleet Foxes",			"White Winter Hymnal");
Scraper( "Joel Plaskett",		"Nowhere With You");
Scraper( "Red Hot Chili Peppers","Under The Bridge");
Scraper( "Phoenix","Lisztomania");
Scraper( "Vampire Weekend","Run");
Scraper( "Kings Of Leon","Sex On Fire");
Scraper( "Tokyo Police Club","Bambi");
Scraper( "U2","Sunday Bloody Sunday");
Scraper( "Arcade Fire","Wake Up");
Scraper( "Jack Johnson","Better Together");
Scraper( "Cake","Sick Of You");
Scraper( "54-40","One Gun");
Scraper( "Lily Allen","The Fear");
Scraper( "Incubus","Drive");
Scraper( "Metric","Poster Of A Girl");
Scraper( "Lou Reed","Walk On The Wild Side");
Scraper( "Neon Trees","Animal");
Scraper( "OK Go","This Too Shall Pass");
Scraper( "Lenny Kravitz","Are You Gonna Go My Way");
Scraper( "Auf Der Maur","Followed The Waves");
Scraper( "Stereophonics","Have A Nice Day");
Scraper( "Nirvana","All Apologies");
Scraper( "Violent Femmes","Add It Up");
Scraper( "Cage The Elephant","Shake Me Down");
Scraper( "Vampire Weekend","A-Punk");
Scraper( "David Gray","Babylon");
Scraper( "Broken Bells","The Ghost Inside");
Scraper( "Sloan","Live On");
Scraper( "Switchfoot","Meant To Live");
Scraper( "Green Day","Basket Case");
Scraper( "Stars","Fixed");
Scraper( "Death Cab For Cutie","I Will Possess Your Heart");
Scraper( "Spacehog","In The Meantime");
Scraper( "Pearl Jam","Just Breathe");
Scraper( "Modest Mouse","Dashboard");
Scraper( "Stone Temple Pilots","Interstate Love Song");
Scraper( "Clash","Clampdown");
Scraper( "Jeremy Fisher", 		"Shine A Little Light");
Scraper( "Fitz & The Tantrums",	"Money Grabber");
Scraper( "Elliott Brood",		"The Valley Town");
Scraper( "Tired Pony","Dead American Writers");
Scraper( "Vince Vaccaro","Costa Rica");
Scraper( "National","Blood Buzz Ohio");
Scraper( "Edward Sharpe & The Magnetic Zeros","40 Day Dream");
Scraper( "Black Mountain","The Hair Song");
Scraper( "Decemberists","Down By The Water");
Scraper( "Deerhunter","Helicopter");
Scraper( "Jon & Roy","Any Day Now");
Scraper( "Band Of Horses","Georgia");
Scraper( "Florence + The Machine","Cosmic Love");
Scraper( "Sam Roberts","Don't Walk Away Eileen");
Scraper( "One eskimO","Kandi");
Scraper( "Hot Hot Heat","No, Not Now");
Scraper( "Matt & Kim","Cameras");
Scraper( "Hey Rosetta!","I've Been Asleep For A Long, Long Time");
Scraper( "Michael Bernard Fitzgerald","Movie Life");
Scraper( "Mumford & Sons","Little Lion Man");
Scraper( "Tegan & Sara","Call It Off");
Scraper( "Marcy Playground","Sex & Candy");
Scraper( "Guilty About Girls","Luv");
Scraper( "Ray Lamontagne & The Pariah Dogs","For The Summer");
Scraper( "Matt Mays & El Torpedo","The Past");
Scraper( "Mother Mother","The Stand");
Scraper( "Justice","D.A.N.C.E.");
Scraper( "Kyprios","City Woman");
Scraper( "Dirty Heads Feat. Rome","Lay Me Down");
Scraper( "Said The Whale","Camilo (The Magician)");
Scraper( "Arcade Fire","The Suburbs");
Scraper( "Aidan Knight","Jasper");
Scraper( "Black Keys","Everlasting Light");
Scraper( "Golden Dogs","Construction Worker");
Scraper( "Citizen Cope","Son's Gonna Rise");
Scraper( "Dudes","Dropkick Queen Of The Weekend");
Scraper( "Jon & Roy","Get Myself A Gun");
Scraper( "Elliott Brood","The Valley Town");
Scraper( "Doves","There Goes The Fear");
Scraper( "Adele","Rolling In The Deep");
Scraper( "Dave Matthews Band","The Space Between");
Scraper( "Matt & Kim","Daylight");
Scraper( "Band Of Horses","Georgia");
Scraper( "Rufus Wainwright","Across The Universe");
Scraper( "Weezer","Say It Ain't So");
Scraper( "Cold War Kids","Audience");
Scraper( "Blur","Country House");
Scraper( "Iggy Pop","Lust For Life");
Scraper( "Edward Sharpe & The Magnetic Zeros","40 Day Dream");
Scraper( "Sam Roberts","Hard Road");
Scraper( "Smashing Pumpkins","Today");
Scraper( "Mother Mother","Wrecking Ball");
Scraper( "Yeah Yeah Yeahs","Sheena Is A Punk Rocker");
Scraper( "Sublime","Santeria");
Scraper( "Fitz & The Tantrums","Money Grabber");
Scraper( "Beck","Where It's At");
Scraper( "Jeremy Fisher","Shine A Little Light");
Scraper( "Foo Fighters","Long Road To Ruin");
Scraper( "City And Colour","Comin' Home");
Scraper( "Death Cab For Cutie","Little Bribes");
Scraper( "Guster","Do You Love Me?");
Scraper( "Red Hot Chili Peppers","Soul To Squeeze");
Scraper( "Talking Heads","Take Me To The River");
Scraper( "Kings Of Leon","Back Down South");
Scraper( "Metric","Gimme Sympathy");
Scraper( "Cat Empire","The Chariot");
Scraper( "Postal Service","Such Great Heights");
Scraper( "Hey Rosetta!","Red Heart");
Scraper( "Violent Femmes","Blister In The Sun");
Scraper( "Florence + The Machine","Cosmic Love");
Scraper( "New Pornographers","Crash Years");
Scraper( "Placebo","Pure Morning");
Scraper( "Interpol","Barricade");
Scraper( "Royal Wood","On Top Of Your Love");
Scraper( "R.E.M.","The One I Love");
Scraper( "Phoenix","1901");
Scraper( "Nirvana","Polly");
Scraper( "Big Wreck","Blown Wide Open");
Scraper( "Snow Patrol","Crack The Shutters");
Scraper( "Sweet Thing","Change Of Seasons");
Scraper( "Oasis","Wonderwall");
Scraper( "Plants And Animals","The Mama Papa");
Scraper( "Pulp","Common People");
Scraper( "Vampire Weekend","Run");
Scraper( "Stone Temple Pilots","Big Empty");
Scraper( "Kate Nash","Foundations");
Scraper( "Naked And Famous","Young Blood");
Scraper( "Naked & Famous","Young Blood");
Scraper( "Jason Collett","Hangover Days");
Scraper( "311","Amber");
Scraper( "Band Of Skulls","I Know What I Am");
Scraper( "Folk Implosion","Natural One");
Scraper( "Arcade Fire","Ready To Start");
Scraper( "Sam Roberts","Dead End");
Scraper( "Kings Of Leon","Fans");
Scraper( "Ray Lamontagne & The Pariah Dogs","For The Summer");
Scraper( "Blur","Country House");
Scraper( "Tegan & Sara","Northshore");
Scraper( "Dave Matthews Band","Why I Am");
Scraper( "The Tragically Hip","My Music @ Work");
Scraper( "Brandon Flowers","Only The Young");
Scraper( "U2","Sweetest Thing");
Scraper( "Dudes","Mr. Someone Else");
Scraper( "National","Blood Buzz Ohio");
Scraper( "Big Sugar","Diggin' A Hole");
Scraper( "Pearl Jam","Better Man");
Scraper( "Diamond Rings","Something Else");
Scraper( "Decemberists","Down By The Water");
Scraper( "Stills","Being Here");
Scraper( "Cold War Kids","We Used To Vacation");
Scraper( "Mumford & Sons","Little Lion Man");
Scraper( "Mother Mother","The Stand");
Scraper( "Raconteurs","Steady, As She Goes");
Scraper( "Jeremy Fisher","Shine A Little Light");
Scraper( "Hey Rosetta!","I've Been Asleep For A Long, Long Time");
Scraper( "Velvet Underground","Sweet Jane");
Scraper( "Black Keys","Everlasting Light");
Scraper( "M. Ward","Chinese Translation");
Scraper( "Sloan","Who Taught You How To Live Like That");
Scraper( "Weezer","Buddy Holly");
Scraper( "Neon Trees","Animal");
Scraper( "Said The Whale","Camilo (The Magician)");
Scraper( "U2","Beautiful Day");
Scraper( "Pilot Speed","Barely Listening");
Scraper( "Jet","Are You Gonna Be My Girl");
Scraper( "Kyprios","City Woman");
Scraper( "Pixies","Monkey Gone To Heaven");
Scraper( "Kings Of Leon","Radioactive");
Scraper( "Sam Roberts","Fixed To Ruin");
Scraper( "Beck","Where It's At");
Scraper( "R.E.M.","What's The Frequency, Kenneth?");
Scraper( "New Pornographers","Crash Years");
Scraper( "Stills","Being Here");
Scraper( "Postal Service","Such Great Heights");
Scraper( "Tegan & Sara","The Con");
Scraper( "Black Keys","Everlasting Light");
Scraper( "Dudes","Girl Police");
Scraper( "Modest Mouse","Dashboard");
Scraper( "Daniel Wesley","Driftin'");
Scraper( "Ray Lamontagne & The Pariah Dogs","For The Summer");
Scraper( "Broken Bells","The High Road");
Scraper( "Golden Dogs","Birdsong");
Scraper( "Snow Patrol","Hands Open");
Scraper( "Gord Downie & The Country Of Miracles","The East Wind");
Scraper( "Brandon Flowers","Only The Young");
Scraper( "Naked And Famous","Young Blood");
Scraper( "Nirvana","Come As You Are");
Scraper( "Porno For Pyros","Pets");
Scraper( "Mother Mother","The Stand");
Scraper( "Metric","Gold Guns Girls");
Scraper( "Dave Matthews Band","Ants Marching");
Scraper( "Hollerado","Juliette");
Scraper( "Death Cab For Cutie","Little Bribes");
Scraper( "Shins","New Slang");
Scraper( "Jeremy Fisher","Shine A Little Light");
Scraper( "Decemberists","Down By The Water");
Scraper( "Kate Nash","Foundations");
Scraper( "Feist","I Feel It All");
Scraper( "Edward Sharpe & The Magnetic Zeros","40 Day Dream");
Scraper( "Green Day","American Idiot");
Scraper( "Arcade Fire","The Suburbs");
Scraper( "Slave To The Squarewave","Big Change");
Scraper( "Pixies","Monkey Gone To Heaven");
Scraper( "Matthew Barber","We're Gonna Play");
Scraper( "Gomez","See The World");
Scraper( "Coldplay","Viva La Vida");
Scraper( "City And Colour","At The Bird's Foot");
Scraper( "Snow Patrol","Take Back The City");
Scraper( "Hawksley Workman","Jealous Of Your Cigarette");
Scraper( "Adele","Rolling In The Deep");
Scraper( "Foo Fighters","Next Year");
Scraper( "Elliott Brood","The Valley Town");
Scraper( "Interpol","Barricade");
Scraper( "Great Lake Swimmers","Still");
Scraper( "Ramones","I Wanna Be Sedated");
Scraper( "Joel Plaskett","Nowhere With You");
Scraper( "Red Hot Chili Peppers","Higher Ground");
Scraper( "Sublime","Badfish");
Scraper( "Fatboy Slim","Praise You");
Scraper( "Kings Of Leon","Back Down South");
Scraper( "Pulp","Common People");
Scraper( "Boy","Up In This Town");
Scraper( "Fitz & The Tantrums","Money Grabber");
Scraper( "U2","Elevation");
Scraper( "Silverchair","Straight Lines");
Scraper( "Sam Roberts","Mind Flood");
Scraper( "Yeah Yeah Yeahs","Sheena Is A Punk Rocker");
Scraper( "Vince Vaccaro","Catch A Fire");
Scraper( "Smashing Pumpkins","1979");
Scraper( "Muse","Time Is Running Out");
Scraper( "Band Of Horses","Georgia");
Scraper( "Band Of Skulls","I Know What I Am");
Scraper( "Stone Temple Pilots","Big Empty");
Scraper( "Plants And Animals","The Mama Papa");
Scraper( "David Bowie","Changes");
Scraper( "Amos Lee","Windows Are Rolled Down");
Scraper( "The Tragically Hip","Poets");
Scraper( "Foo Fighters","Everlong");
Scraper( "Hannah Georgas","The Deep End");
Scraper( "Noah And The Whale","5 Years Time");
Scraper( "Radiohead","Karma Police");
Scraper( "Florence + The Machine","Cosmic Love");
Scraper( "Coldplay","Clocks");
Scraper( "Russian Futurists","Hoeing Weeds, Sowing Seeds");
Scraper( "Cake","Never There");
Scraper( "Chromeo","Fancy Footwork");
Scraper( "Mumford & Sons","Little Lion Man");
Scraper( "Naked And Famous","Young Blood");
Scraper( "Incubus","Dig");
Scraper( "Blind Melon","No Rain");
Scraper( "National","Terrible Love");
Scraper( "New Pornographers","Your Hands (Together)");
Scraper( "Flys","Got You Where I Want You/Te Tengo Como Quiero");
Scraper( "Snow Patrol","Chocolate");
Scraper( "Tegan & Sara","Hell");
Scraper( "Cure","Close To Me");
Scraper( "Vampire Weekend","Run");
Scraper( "Hey Rosetta!","Welcome");
Scraper( "Spoon","Don't You Evah");
Scraper( "R.E.M.","Discoverer");
Scraper( "Beast","Mr. Hurricane");
Scraper( "Butthole Surfers","Pepper");
Scraper( "Crash Kings","Mountain Man");
Scraper( "INXS","Mystify");
Scraper( "Lily Allen","The Fear");
Scraper( "Hawksley Workman","Piano Blink (The Break Up Song)");
Scraper( "Killers","Somebody Told Me");
Scraper( "Stars","How Much More");
Scraper( "Jack Johnson","The Horizon Has Been Defeated");
Scraper( "Jets Overhead","Heading For Nowhere");
Scraper( "Refreshments","Banditos");
Scraper( "Ray Lamontagne & The Pariah Dogs","For The Summer");
Scraper( "Everclear","I Will Buy You A New Life");
Scraper( "Pixies","Monkey Gone To Heaven");
Scraper( "Tired Pony","Dead American Writers");
Scraper( "Patrick Watson","The Great Escape");
Scraper( "U2","New Year's Day");
Scraper( "Mumford & Sons","The Cave");
Scraper( "Silversun Pickups","Lazy Eye");
Scraper( "Radiohead","Fake Plastic Trees");
Scraper( "Cage The Elephant","Shake Me Down");
Scraper( "Feist","1234");
Scraper( "Lenny Kravitz","Are You Gonna Go My Way");
Scraper( "Said The Whale","Camilo (The Magician)");
Scraper( "Amy Winehouse","Rehab");
Scraper( "Coldplay","In My Place");
Scraper( "Mother Mother","The Stand");
Scraper( "Green Day","Longview");
Scraper( "Bedouin Soundclash","Mountain Top");
Scraper( "Weezer","Dope Nose");
Scraper( "Broken Social Scene","7/4 (Shoreline)");
Scraper( "Dirty Heads Feat. Rome","Lay Me Down");
Scraper( "Cold War Kids","Louder Than Ever");
Scraper( "Temple Of The Dog","Hunger Strike");
Scraper( "MGMT","Kids");
Scraper( "Broken Bells","The Ghost Inside");
Scraper( "Golden Dogs","1985");
Scraper( "OK Go","Here It Goes Again");
Scraper( "Clash","Train In Vain (Stand By Me)");
Scraper( "City And Colour","Sleeping Sickness");
Scraper( "Foo Fighters","This Is A Call");
Scraper( "Arcade Fire","The Suburbs");
Scraper( "Kyprios","City Woman");
Scraper( "Yeah Yeah Yeahs","Gold Lion");
Scraper( "Neon Trees","Animal");
Scraper( "Islands","Creeper");
Scraper( "Modest Mouse","Missed The Boat");
Scraper( "Florence + The Machine","Dog Days Are Over");
Scraper( "Red Hot Chili Peppers","Zephyr Song");
Scraper( "Zolas","You're Too Cool");
Scraper( "Smiths","Panic");
Scraper( "Metric","Dead Disco");
Scraper( "Phoenix","Lisztomania");
Scraper( "By Divine Right","Supernatural");
Scraper( "Adele","Rolling In The Deep");
Scraper( "Nirvana","Lake Of Fire");
Scraper( "Stars","How Much More");
Scraper( "R.E.M.","It's The End Of The World As We Know It (And I Feel Fine)");
Scraper( "Mother Mother","Wrecking Ball");
Scraper( "Interpol","Barricade");
Scraper( "Band Of Horses","Is There A Ghost");
Scraper( "Matthew Good Band","Symbolistic White Walls");
Scraper( "Sublime","Santeria");


?>