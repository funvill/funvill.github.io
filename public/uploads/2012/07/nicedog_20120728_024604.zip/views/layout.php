This is from view/layout.php 
<?php echo $this->content ?>
