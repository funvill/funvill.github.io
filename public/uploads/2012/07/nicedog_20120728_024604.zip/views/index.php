This is the view/index.php
Tag=<?php echo $tag ; ?>