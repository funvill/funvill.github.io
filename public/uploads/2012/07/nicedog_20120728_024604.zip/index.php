<?php 
/** 
  * Created by: Steven Smethurst 
  * Created on: 28 July 2012 
  * 
  * A example file for NiceDog php nano web framework found https://github.com/bastos/nicedog
  */
require 'NiceDog.php';
R('')->controller('Test')->action('index')->on('GET');
R('foo')->controller('Test')->action('update')->on('GET');
R('tag/(?P<tag>[-\w]+)')->controller('Test')->action('p_tag')->on('GET');

class Test extends C{

    public function index(){
        echo 'Hello world';
    }
	public function foo(){ 
		echo "bar";
	}	
	public function p_tag($tag){ 
		$this->tag = $tag; 
	    echo $this->render('views/index.php');	
	}
}

// This is the error page. 
function r404() {
	echo "Error: 404 Page not found"; 
}

run();
?>